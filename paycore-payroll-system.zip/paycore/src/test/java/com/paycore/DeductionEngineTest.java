package com.paycore;

import com.paycore.service.DeductionEngine;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DeductionEngineTest {

    private DeductionEngine engine;

    @BeforeEach
    void setUp() {
        engine = new DeductionEngine();
    }

    @Test
    void testZeroTaxBelowSlab() {
        // Annual ₹4L = 0% slab
        double tds = engine.calculateAnnualTDS(400_000);
        assertEquals(0, tds);
    }

    @Test
    void testFivePercentSlab() {
        // Annual ₹6L → 5% on ₹2L = ₹10,000 + 4% cess
        double tds = engine.calculateAnnualTDS(600_000);
        assertTrue(tds > 0);
    }

    @Test
    void testNetSalaryCalculation() {
        DeductionEngine.DeductionResult r = engine.calculate(100_000);
        assertEquals(100_000, r.gross(), 0.01);
        assertEquals(50_000, r.basic(), 0.01);
        assertEquals(20_000, r.hra(), 0.01);
        assertTrue(r.netSalary() < r.gross());
        assertEquals(r.gross() - r.totalDeductions(), r.netSalary(), 1.0);
    }

    @Test
    void testESIAppliesOnlyBelow21k() {
        // ₹15,000 gross — ESI should apply
        DeductionEngine.DeductionResult low = engine.calculate(15_000);
        assertTrue(low.esi() > 0);

        // ₹85,000 gross — ESI should NOT apply
        DeductionEngine.DeductionResult high = engine.calculate(85_000);
        assertEquals(0.0, high.esi());
    }

    @Test
    void testPFIsAlways12PercentOfBasic() {
        DeductionEngine.DeductionResult r = engine.calculate(80_000);
        double expectedBasic = Math.round(80_000 * 0.5);
        double expectedPF    = Math.round(expectedBasic * 0.12);
        assertEquals(expectedPF, r.providentFund(), 1.0);
    }

    @Test
    void testProfessionalTaxIsFixed200() {
        DeductionEngine.DeductionResult r = engine.calculate(200_000);
        assertEquals(200.0, r.professionalTax());
    }
}
