package com.paycore.repository;

import com.paycore.model.Payroll;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PayrollRepository extends JpaRepository<Payroll, Long> {
    List<Payroll> findByPayMonthAndPayYear(int month, int year);
    List<Payroll> findByEmployee_EmployeeId(String employeeId);
    Optional<Payroll> findByEmployee_EmployeeIdAndPayMonthAndPayYear(String empId, int month, int year);

    @Query("SELECT SUM(p.grossSalary) FROM Payroll p WHERE p.payMonth = :month AND p.payYear = :year")
    Double getTotalGrossForMonth(int month, int year);

    @Query("SELECT SUM(p.netSalary) FROM Payroll p WHERE p.payMonth = :month AND p.payYear = :year")
    Double getTotalNetForMonth(int month, int year);

    @Query("SELECT SUM(p.tds + p.providentFund + p.esi + p.professionalTax) FROM Payroll p WHERE p.payMonth = :month AND p.payYear = :year")
    Double getTotalDeductionsForMonth(int month, int year);
}
