package com.paycore.controller;

import com.paycore.model.Payroll;
import com.paycore.service.DeductionEngine;
import com.paycore.service.PayrollService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/payroll")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class PayrollController {

    private final PayrollService payrollService;
    private final DeductionEngine deductionEngine;

    /** Run payroll for the given period */
    @PostMapping("/run")
    public ResponseEntity<List<Payroll>> runPayroll(
            @RequestParam int month,
            @RequestParam int year) {
        return ResponseEntity.ok(payrollService.runPayroll(month, year));
    }

    /** Get all payroll records for a period */
    @GetMapping
    public ResponseEntity<List<Payroll>> getPayroll(
            @RequestParam int month,
            @RequestParam int year) {
        return ResponseEntity.ok(payrollService.getPayrollByPeriod(month, year));
    }

    /** Get payroll history for one employee */
    @GetMapping("/employee/{employeeId}")
    public ResponseEntity<List<Payroll>> getEmployeePayroll(@PathVariable String employeeId) {
        return ResponseEntity.ok(payrollService.getPayrollByEmployee(employeeId));
    }

    /** Get a specific payslip */
    @GetMapping("/payslip/{employeeId}")
    public ResponseEntity<Payroll> getPayslip(
            @PathVariable String employeeId,
            @RequestParam int month,
            @RequestParam int year) {
        return ResponseEntity.ok(payrollService.getPayslip(employeeId, month, year));
    }

    /** Payroll summary dashboard data */
    @GetMapping("/summary")
    public ResponseEntity<PayrollService.PayrollSummary> getSummary(
            @RequestParam int month,
            @RequestParam int year) {
        return ResponseEntity.ok(payrollService.getSummary(month, year));
    }

    /** Live deduction calculator endpoint */
    @GetMapping("/calculate")
    public ResponseEntity<Map<String, Double>> calculate(@RequestParam double grossSalary) {
        DeductionEngine.DeductionResult r = deductionEngine.calculate(grossSalary);
        return ResponseEntity.ok(Map.of(
            "gross",            r.gross(),
            "basic",            r.basic(),
            "hra",              r.hra(),
            "specialAllowance", r.specialAllowance(),
            "tds",              r.tds(),
            "providentFund",    r.providentFund(),
            "esi",              r.esi(),
            "professionalTax",  r.professionalTax(),
            "totalDeductions",  r.totalDeductions(),
            "netSalary",        r.netSalary()
        ));
    }
}
