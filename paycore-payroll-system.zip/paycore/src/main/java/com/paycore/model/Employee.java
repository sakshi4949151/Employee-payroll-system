package com.paycore.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "employees")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String employeeId;   // e.g. EMP001

    @Column(nullable = false)
    private String name;

    @Column(unique = true, nullable = false)
    private String email;

    private String phone;
    private String department;
    private String role;

    @Column(nullable = false)
    private Double grossSalary;   // monthly gross

    private Double basicSalary;   // 50% of gross
    private Double hra;           // 20% of gross
    private Double specialAllowance;

    @Column(unique = true)
    private String panNumber;

    private String bankAccount;
    private String ifscCode;

    private LocalDate joiningDate;

    @Enumerated(EnumType.STRING)
    private EmployeeStatus status;

    public enum EmployeeStatus {
        ACTIVE, INACTIVE, ON_LEAVE
    }
}
