package com.paycore.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "payrolls")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Payroll {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;

    @Column(nullable = false)
    private Integer payMonth;   // 1-12

    @Column(nullable = false)
    private Integer payYear;

    private Double grossSalary;
    private Double basicSalary;
    private Double hra;
    private Double specialAllowance;

    // Deductions
    private Double tds;
    private Double providentFund;     // 12% of basic
    private Double esi;               // 1.75% if gross <= 21000
    private Double professionalTax;   // ₹200/month
    private Double totalDeductions;

    private Double netSalary;

    private Integer daysWorked;
    private Integer totalDays;

    @Enumerated(EnumType.STRING)
    private PayrollStatus status;

    private LocalDate processedDate;
    private String payslipNumber;

    public enum PayrollStatus {
        PENDING, PROCESSED, PAID, CANCELLED
    }
}
