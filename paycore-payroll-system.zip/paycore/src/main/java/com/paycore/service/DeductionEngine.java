package com.paycore.service;

import org.springframework.stereotype.Component;

/**
 * Tax Deduction Engine — Indian New Tax Regime (FY 2025-26)
 * Calculates TDS, PF, ESI, and Professional Tax
 */
@Component
public class DeductionEngine {

    // Indian New Tax Regime slabs (FY 2025-26)
    private static final double SLAB_0_LIMIT    = 400_000;
    private static final double SLAB_5_LIMIT    = 800_000;
    private static final double SLAB_10_LIMIT   = 1_200_000;
    private static final double SLAB_15_LIMIT   = 1_600_000;
    private static final double SLAB_20_LIMIT   = 2_000_000;
    private static final double SLAB_25_LIMIT   = 2_400_000;

    // Statutory deduction rates
    public static final double PF_RATE          = 0.12;   // 12% of basic
    public static final double ESI_RATE         = 0.0175; // 1.75% of gross
    public static final double ESI_GROSS_LIMIT  = 21_000; // ESI applies if gross <= ₹21,000
    public static final double PROFESSIONAL_TAX = 200.0;  // ₹200/month fixed

    public static final double BASIC_PERCENT    = 0.50;   // 50% of gross
    public static final double HRA_PERCENT      = 0.20;   // 20% of gross

    public record DeductionResult(
        double gross,
        double basic,
        double hra,
        double specialAllowance,
        double tds,
        double providentFund,
        double esi,
        double professionalTax,
        double totalDeductions,
        double netSalary
    ) {}

    public DeductionResult calculate(double monthlyGross) {
        double annual = monthlyGross * 12;

        double basic            = Math.round(monthlyGross * BASIC_PERCENT);
        double hra              = Math.round(monthlyGross * HRA_PERCENT);
        double specialAllowance = monthlyGross - basic - hra;

        double tds  = Math.round(calculateAnnualTDS(annual) / 12.0);
        double pf   = Math.round(basic * PF_RATE);
        double esi  = monthlyGross <= ESI_GROSS_LIMIT ? Math.round(monthlyGross * ESI_RATE) : 0.0;
        double pt   = PROFESSIONAL_TAX;

        double totalDeductions = tds + pf + esi + pt;
        double net = monthlyGross - totalDeductions;

        return new DeductionResult(
            monthlyGross, basic, hra, specialAllowance,
            tds, pf, esi, pt, totalDeductions, net
        );
    }

    /**
     * Progressive slab calculation — New Tax Regime FY 2025-26
     */
    public double calculateAnnualTDS(double annualIncome) {
        if (annualIncome <= SLAB_0_LIMIT) return 0;

        double tax = 0;

        if (annualIncome > SLAB_25_LIMIT)
            tax += (annualIncome - SLAB_25_LIMIT) * 0.30;

        if (annualIncome > SLAB_20_LIMIT)
            tax += Math.min(annualIncome - SLAB_20_LIMIT, SLAB_25_LIMIT - SLAB_20_LIMIT) * 0.25;

        if (annualIncome > SLAB_15_LIMIT)
            tax += Math.min(annualIncome - SLAB_15_LIMIT, SLAB_20_LIMIT - SLAB_15_LIMIT) * 0.20;

        if (annualIncome > SLAB_10_LIMIT)
            tax += Math.min(annualIncome - SLAB_10_LIMIT, SLAB_15_LIMIT - SLAB_10_LIMIT) * 0.15;

        if (annualIncome > SLAB_5_LIMIT)
            tax += Math.min(annualIncome - SLAB_5_LIMIT, SLAB_10_LIMIT - SLAB_5_LIMIT) * 0.10;

        if (annualIncome > SLAB_0_LIMIT)
            tax += Math.min(annualIncome - SLAB_0_LIMIT, SLAB_5_LIMIT - SLAB_0_LIMIT) * 0.05;

        // Surcharge 12% if annual income > ₹1 Crore
        if (annualIncome > 10_000_000) tax += tax * 0.12;

        // Health & Education Cess: 4%
        tax += tax * 0.04;

        return Math.round(tax);
    }

    public String getTaxSlabLabel(double annual) {
        if (annual <= SLAB_0_LIMIT)  return "0%";
        if (annual <= SLAB_5_LIMIT)  return "5%";
        if (annual <= SLAB_10_LIMIT) return "10%";
        if (annual <= SLAB_15_LIMIT) return "15%";
        if (annual <= SLAB_20_LIMIT) return "20%";
        if (annual <= SLAB_25_LIMIT) return "25%";
        return "30%";
    }
}
