package com.paycore.service;

import com.paycore.model.Employee;
import com.paycore.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final DeductionEngine deductionEngine;

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Employee getByEmployeeId(String employeeId) {
        return employeeRepository.findByEmployeeId(employeeId)
            .orElseThrow(() -> new RuntimeException("Employee not found: " + employeeId));
    }

    @Transactional
    public Employee createEmployee(Employee emp) {
        if (employeeRepository.existsByEmail(emp.getEmail()))
            throw new RuntimeException("Email already registered: " + emp.getEmail());
        if (employeeRepository.existsByPanNumber(emp.getPanNumber()))
            throw new RuntimeException("PAN already registered: " + emp.getPanNumber());

        // Auto-generate employee ID
        long count = employeeRepository.count() + 1;
        emp.setEmployeeId(String.format("EMP%03d", count));

        // Auto-calculate salary components
        double gross = emp.getGrossSalary();
        emp.setBasicSalary(Math.round(gross * DeductionEngine.BASIC_PERCENT));
        emp.setHra(Math.round(gross * DeductionEngine.HRA_PERCENT));
        emp.setSpecialAllowance(gross - emp.getBasicSalary() - emp.getHra());

        if (emp.getStatus() == null) emp.setStatus(Employee.EmployeeStatus.ACTIVE);

        return employeeRepository.save(emp);
    }

    @Transactional
    public Employee updateEmployee(String employeeId, Employee updated) {
        Employee existing = getByEmployeeId(employeeId);
        existing.setName(updated.getName());
        existing.setPhone(updated.getPhone());
        existing.setDepartment(updated.getDepartment());
        existing.setRole(updated.getRole());
        existing.setStatus(updated.getStatus());

        if (!existing.getGrossSalary().equals(updated.getGrossSalary())) {
            existing.setGrossSalary(updated.getGrossSalary());
            double gross = updated.getGrossSalary();
            existing.setBasicSalary(Math.round(gross * DeductionEngine.BASIC_PERCENT));
            existing.setHra(Math.round(gross * DeductionEngine.HRA_PERCENT));
            existing.setSpecialAllowance(gross - existing.getBasicSalary() - existing.getHra());
        }
        return employeeRepository.save(existing);
    }

    @Transactional
    public void deleteEmployee(String employeeId) {
        Employee emp = getByEmployeeId(employeeId);
        emp.setStatus(Employee.EmployeeStatus.INACTIVE);
        employeeRepository.save(emp);
    }

    public List<Employee> getByDepartment(String dept) {
        return employeeRepository.findByDepartment(dept);
    }

    public List<Employee> getActiveEmployees() {
        return employeeRepository.findByStatus(Employee.EmployeeStatus.ACTIVE);
    }
}
