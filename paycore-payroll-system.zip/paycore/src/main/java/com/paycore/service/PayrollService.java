package com.paycore.service;

import com.paycore.model.Employee;
import com.paycore.model.Payroll;
import com.paycore.repository.EmployeeRepository;
import com.paycore.repository.PayrollRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class PayrollService {

    private final PayrollRepository payrollRepository;
    private final EmployeeRepository employeeRepository;
    private final DeductionEngine deductionEngine;

    /**
     * Process payroll for ALL active employees for the given month/year.
     * This is the core 100% automated payroll engine.
     */
    @Transactional
    public List<Payroll> runPayroll(int month, int year) {
        log.info("Starting payroll run for {}/{}", month, year);

        List<Employee> activeEmployees = employeeRepository
            .findByStatus(Employee.EmployeeStatus.ACTIVE);

        List<Payroll> processed = new ArrayList<>();

        for (Employee emp : activeEmployees) {
            // Skip if already processed for this period
            boolean exists = payrollRepository
                .findByEmployee_EmployeeIdAndPayMonthAndPayYear(emp.getEmployeeId(), month, year)
                .isPresent();

            if (exists) {
                log.warn("Payroll already processed for {} - {}/{}", emp.getEmployeeId(), month, year);
                continue;
            }

            DeductionEngine.DeductionResult calc = deductionEngine.calculate(emp.getGrossSalary());

            Payroll payroll = Payroll.builder()
                .employee(emp)
                .payMonth(month)
                .payYear(year)
                .grossSalary(calc.gross())
                .basicSalary(calc.basic())
                .hra(calc.hra())
                .specialAllowance(calc.specialAllowance())
                .tds(calc.tds())
                .providentFund(calc.providentFund())
                .esi(calc.esi())
                .professionalTax(calc.professionalTax())
                .totalDeductions(calc.totalDeductions())
                .netSalary(calc.netSalary())
                .daysWorked(30)
                .totalDays(30)
                .status(Payroll.PayrollStatus.PROCESSED)
                .processedDate(LocalDate.now())
                .payslipNumber("PSL-" + year + String.format("%02d", month)
                    + "-" + emp.getEmployeeId())
                .build();

            processed.add(payrollRepository.save(payroll));
            log.info("Payroll processed for {} | Net: ₹{}", emp.getEmployeeId(), calc.netSalary());
        }

        log.info("Payroll run complete. {} records processed.", processed.size());
        return processed;
    }

    public List<Payroll> getPayrollByPeriod(int month, int year) {
        return payrollRepository.findByPayMonthAndPayYear(month, year);
    }

    public List<Payroll> getPayrollByEmployee(String employeeId) {
        return payrollRepository.findByEmployee_EmployeeId(employeeId);
    }

    public Payroll getPayslip(String employeeId, int month, int year) {
        return payrollRepository
            .findByEmployee_EmployeeIdAndPayMonthAndPayYear(employeeId, month, year)
            .orElseThrow(() -> new RuntimeException("Payslip not found for " + employeeId));
    }

    public record PayrollSummary(double totalGross, double totalNet, double totalDeductions, int employeeCount) {}

    public PayrollSummary getSummary(int month, int year) {
        Double gross = payrollRepository.getTotalGrossForMonth(month, year);
        Double net   = payrollRepository.getTotalNetForMonth(month, year);
        Double ded   = payrollRepository.getTotalDeductionsForMonth(month, year);
        int count    = payrollRepository.findByPayMonthAndPayYear(month, year).size();
        return new PayrollSummary(
            gross != null ? gross : 0,
            net   != null ? net   : 0,
            ded   != null ? ded   : 0,
            count
        );
    }
}
