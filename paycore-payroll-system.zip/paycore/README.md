# PayCore — Employee Payroll Management System

Full-stack payroll system built with **Java 17 + Spring Boot 3.2 + Hibernate 6**.  
CI/CD via **GitHub Actions**, deployed live on **Netlify**.

---

## Tech Stack

| Layer        | Technology                          |
|-------------|--------------------------------------|
| Backend      | Java 17, Spring Boot 3.2, Hibernate 6 |
| Database     | MySQL 8 (H2 for tests)               |
| Security     | Spring Security + JWT                |
| API Docs     | Swagger / OpenAPI 3                  |
| Frontend     | React, Tailwind CSS                  |
| CI/CD        | GitHub Actions                       |
| Deployment   | Netlify (frontend), Docker (backend) |

---

## Features

- **100% Automated Payroll** — run payroll for all employees in one API call
- **Tax Engine** — Indian New Regime FY 2025-26 (progressive slabs 0–30%)
- **Deductions** — TDS, PF (12% of basic), ESI (1.75%), Professional Tax
- **Payslip Generation** — per employee, per month
- **REST API** — full CRUD for employees and payroll
- **CI/CD Pipeline** — test → build → docker → deploy on every push to main

---

## Getting Started

### Prerequisites
- Java 17+
- Maven 3.9+
- MySQL 8

### Run locally

```bash
# 1. Clone
git clone https://github.com/yourname/paycore.git
cd paycore

# 2. Configure DB in src/main/resources/application.properties

# 3. Build & run
mvn clean install
mvn spring-boot:run
```

API available at: `http://localhost:8080`  
Swagger UI: `http://localhost:8080/swagger-ui.html`

---

## API Endpoints

### Employees
| Method | Endpoint                        | Description          |
|--------|---------------------------------|----------------------|
| GET    | /api/employees                  | List all employees   |
| GET    | /api/employees/{id}             | Get employee         |
| POST   | /api/employees                  | Create employee      |
| PUT    | /api/employees/{id}             | Update employee      |
| DELETE | /api/employees/{id}             | Deactivate employee  |

### Payroll
| Method | Endpoint                        | Description          |
|--------|---------------------------------|----------------------|
| POST   | /api/payroll/run?month=4&year=2026 | Run payroll       |
| GET    | /api/payroll?month=4&year=2026  | Get payroll records  |
| GET    | /api/payroll/payslip/{empId}    | Get payslip          |
| GET    | /api/payroll/summary            | Dashboard summary    |
| GET    | /api/payroll/calculate?grossSalary=100000 | Live calculator |

---

## CI/CD Pipeline

```
Push to main
    │
    ├── build-backend   → Maven build + Unit tests + Integration tests
    ├── build-frontend  → npm ci + npm test + npm run build
    ├── docker          → Build image + push to Docker Hub
    └── deploy-netlify  → Deploy frontend to Netlify (live URL)
```

### Required GitHub Secrets
- `NETLIFY_AUTH_TOKEN`
- `NETLIFY_SITE_ID`
- `DOCKER_USERNAME`
- `DOCKER_PASSWORD`
- `API_BASE_URL`

---

## Tax Slab Reference (New Regime FY 2025-26)

| Annual Income      | Rate |
|--------------------|------|
| Up to ₹4,00,000    | 0%   |
| ₹4L – ₹8L         | 5%   |
| ₹8L – ₹12L        | 10%  |
| ₹12L – ₹16L       | 15%  |
| ₹16L – ₹20L       | 20%  |
| ₹20L – ₹24L       | 25%  |
| Above ₹24L        | 30%  |

---

## License
MIT
